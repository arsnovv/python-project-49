#!/usr/bin/env python3
from brain_games.examination import examination


def main():
    examination()



if __name__ == "__main__":
    main()


