### Asciinema:
[![asciicast](https://asciinema.org/a/tezsaFtgfjg60s12fbCCnZkud.svg)](https://asciinema.org/a/tezsaFtgfjg60s12fbCCnZkud)

### Hexlet tests and linter status:
[![Actions Status](https://github.com/arsnovv/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/arsnovv/python-project-49/actions)
