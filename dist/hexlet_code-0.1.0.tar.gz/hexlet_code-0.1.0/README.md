### Ascinema3:
[![asciicast](https://asciinema.org/a/1tDrlhLuvenieJetSGooMVOz0.svg)](https://asciinema.org/a/1tDrlhLuvenieJetSGooMVOz0)

### Ascinema2:
[![asciicast](https://asciinema.org/a/qmb0t0l3nJF2xtN7oRqDgE4gM.svg)](https://asciinema.org/a/qmb0t0l3nJF2xtN7oRqDgE4gM)

### Asciinema1:
[![asciicast](https://asciinema.org/a/tezsaFtgfjg60s12fbCCnZkud.svg)](https://asciinema.org/a/tezsaFtgfjg60s12fbCCnZkud)

### Hexlet tests and linter status:
[![Actions Status](https://github.com/arsnovv/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/arsnovv/python-project-49/actions)
