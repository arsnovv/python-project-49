#!/usr/bin/env python3
from brain_games.games.even import examination


def main():
    examination()


if __name__ == "__main__":
    main()
